// export const serverUrl = 'http://10.10.1.135:4080/obp_bs-1.1.0';
window.config = {
    serverUrl: 'http://10.10.1.135:4080/obp_bs-1.1.0'
}